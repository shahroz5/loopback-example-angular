// Copyright IBM Corp. 2015,2016. All Rights Reserved.
// Node module: loopback-example-angular
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT

var test = require('tape');

test('smoke test', function(t) {
  t.plan(1);
  t.equal(1, 1);
});
